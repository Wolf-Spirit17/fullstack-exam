const Event = require('../models/Event');
const User = require('../models/User');

exports.createEvent = async (req, res) => {
  const { title, description, date } = req.body;
  if (new Date(date) <= new Date()) {
    return res.status(400).json({ msg: 'Event date must be in the future' });
  }

  try {
    const event = new Event({ title, description, date, createdBy: req.user.id });
    await event.save();
    res.json(event);
  } catch (err) {
    res.status(500).send('Server error');
  }
};

exports.getAllEvents = async (req, res) => {
  const events = await Event.find({ date: { $gte: new Date() } });
  res.json(events);
};

exports.registerEvent = async (req, res) => {
  const { eventId } = req.params;
  try {
    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ msg: 'Event not found' });

    if (event.attendees.includes(req.user.id)) {
      return res.status(400).json({ msg: 'Already registered' });
    }

    event.attendees.push(req.user.id);
    await event.save();
    res.json({ msg: 'Registered successfully' });
  } catch (err) {
    res.status(500).send('Server error');
  }
};

exports.getUserEvents = async (req, res) => {
  const { userId } = req.params;
  const events = await Event.find({ attendees: userId });
  res.json(events);
};

exports.cancelRegistration = async (req, res) => {
  const { eventId, userId } = req.params;
  try {
    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ msg: 'Event not found' });

    event.attendees = event.attendees.filter(id => id.toString() !== userId);
    await event.save();
    res.json({ msg: 'Registration cancelled' });
  } catch (err) {
    res.status(500).send('Server error');
  }
};
