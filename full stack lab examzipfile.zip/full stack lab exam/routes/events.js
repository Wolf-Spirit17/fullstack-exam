const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const {
  createEvent,
  getAllEvents,
  registerEvent,
  getUserEvents,
  cancelRegistration
} = require('../controllers/eventController');

router.post('/', auth, createEvent);
router.get('/', getAllEvents);
router.post('/:eventId/register', auth, registerEvent);
router.get('/user/:userId', getUserEvents);
router.delete('/:eventId/cancel/:userId', cancelRegistration);

module.exports = router;
